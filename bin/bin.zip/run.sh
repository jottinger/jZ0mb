echo Starting jZ0mb \(requires Java\)
java Main
